"""Builds the UT lifecycle templates from one shared layout.

Usage: python3 build_ut.py <out_dir>
Every template = shared skeleton + its own content block. Edit the skeleton once,
re-run, and all eight stay consistent. Merge fields use Resend triple-brace syntax,
except message-digest, which is still a server-rendered Handlebars template (see MIGRATION_NOTES).
"""
import sys, pathlib

ASSET = "https://ut.mamuncofoundr.com/email-assets/illustrations"
SITE = "https://ut.mamuncofoundr.com/"
ORANGE, CHARCOAL, SHADE = "#bf5700", "#333f48", "#9cadb7"
PANEL = {  # matches the colour baked into each PNG, used as the images-off fallback
    "welcome": "#bf5700", "weekly-summary": "#d6d2c4", "re-engagement": "#f2ddcc",
    "message-digest": "#f7f6f4", "feature-announcement": "#bf5700", "mutual-match": "#f2ddcc",
    "cofounder-invite": "#d6d2c4", "cofounder-linked": "#e5bc99",
}
SERIF = "Georgia,'Times New Roman',Times,serif"
SANS = "'Helvetica Neue',Helvetica,Arial,sans-serif"

P = f"margin:0 0 18px;padding:0;font-family:{SANS};font-size:15px;line-height:1.7;color:{CHARCOAL};font-weight:400;"
P_LAST = P.replace("margin:0 0 18px", "margin:0")
LINK = f"color:{ORANGE};text-decoration:underline;"


def p(text, last=False):
    return f'<p style="{P_LAST if last else P}">{text}</p>'


def button(label, href):
    return f"""
            <tr>
              <td style="padding:32px 0 0;">
                <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td bgcolor="{ORANGE}" style="background-color:{ORANGE};border-radius:6px;">
                      <a href="{href}" target="_blank" rel="noopener noreferrer nofollow"
                        style="display:inline-block;padding:14px 28px;font-family:{SANS};font-size:11px;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:#ffffff;text-decoration:none;border-radius:6px;"
                        >{label}</a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>"""


def accent_block(inner):
    """Left accent border: the only border the standard allows (quotes, lists)."""
    return f"""<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-left:2px solid {ORANGE};margin:0 0 18px;">
                  <tr><td style="padding:2px 0 2px 16px;">{inner}</td></tr>
                </table>"""


def signoff(name="The Mamun Team", line="UT co-foundr matching · Partnered with the University of Texas"):
    return f"""
            <tr>
              <td style="padding:32px 0 0;">
                <p style="margin:0;padding:0;font-family:{SANS};font-size:14px;line-height:1.6;color:{CHARCOAL};font-weight:600;">{name}</p>
                <p style="margin:0;padding:0;font-family:{SANS};font-size:12px;line-height:1.6;color:{SHADE};">{line}</p>
              </td>
            </tr>"""


def page(*, key, title, preheader, eyebrow, kicker, headline, body, extra_rows="", support=False, unsub="{{{RESEND_UNSUBSCRIBE_URL}}}", alt):
    support_line = (f'<p style="margin:0 0 6px;padding:0;font-family:{SANS};font-size:11px;line-height:1.6;color:{SHADE};">'
                    f'Questions? Reach out at <a href="mailto:support@mamuncofoundr.com" style="color:{SHADE};text-decoration:underline;">support@mamuncofoundr.com</a></p>') if support else ""
    return f"""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no" />
    <title>{title} — UT co-foundr matching</title>
    <style>
      @media only screen and (max-width: 620px) {{
        .outer-pad {{ padding: 24px 16px !important; }}
        .headline {{ font-size: 26px !important; }}
      }}
      @media only screen and (max-width: 480px) {{
        .eyebrow-l, .eyebrow-r {{ display: block !important; width: 100% !important; text-align: left !important; }}
        .eyebrow-r {{ padding: 8px 0 0 !important; }}
        .eyebrow-r span {{ margin-right: 0 !important; }}
        .stack {{ display: block !important; width: 100% !important; padding: 0 0 2px !important; }}
      }}
    </style>
  </head>
  <body style="margin:0;padding:0;background-color:#ffffff;">
    <div style="display:none;max-height:0;max-width:0;overflow:hidden;opacity:0;font-size:1px;line-height:1px;color:#ffffff;mso-hide:all;">{preheader}</div>
    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#ffffff;">
      <tr>
        <td align="center" class="outer-pad" style="padding:40px 24px;">
          <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="540" align="center" style="width:100%;max-width:540px;margin:0 auto;">

            <!-- Eyebrow: wordmark + label (stacks under 480px) -->
            <tr>
              <td style="padding:0 0 20px;">
                <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tr>
                    <td class="eyebrow-l" style="white-space:nowrap;">
                      <span style="font-family:{SANS};font-size:11px;font-weight:700;letter-spacing:3px;color:{CHARCOAL};text-transform:uppercase;">UT CO-FOUNDR MATCHING</span>
                    </td>
                    <td class="eyebrow-r" align="right" style="white-space:nowrap;padding-left:16px;">
                      <span style="font-family:{SANS};font-size:11px;font-weight:700;letter-spacing:3px;color:{SHADE};text-transform:uppercase;margin-right:-3px;">{eyebrow}</span>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Illustration panel (colour baked into the PNG; bgcolor is the images-off fallback) -->
            <tr>
              <td align="center" bgcolor="{PANEL[key]}" style="background-color:{PANEL[key]};border-radius:10px;font-size:0;line-height:0;">
                <img src="{ASSET}/{key}.png" alt="{alt}" width="540"
                  style="display:block;width:100%;max-width:540px;height:auto;margin:0 auto;border:0;outline:none;text-decoration:none;border-radius:10px;" />
              </td>
            </tr>

            <!-- Kicker + serif headline -->
            <tr>
              <td style="padding:36px 0 0;">
                <p style="margin:0 0 10px;padding:0;font-family:{SANS};font-size:11px;font-weight:600;letter-spacing:3px;color:{ORANGE};text-transform:uppercase;">{kicker}</p>
                <h1 class="headline" style="margin:0;padding:0;font-family:{SERIF};font-size:32px;font-weight:400;line-height:1.2;color:{CHARCOAL};letter-spacing:-0.3px;">{headline}</h1>
              </td>
            </tr>

            <!-- Body -->
            <tr>
              <td style="padding:24px 0 0;">
                {body}
              </td>
            </tr>
{extra_rows}
            <!-- Footer -->
            <tr>
              <td style="padding:44px 0 0;">
                {support_line}
                <p style="margin:0;padding:0;font-family:{SANS};font-size:11px;line-height:1.6;color:{SHADE};">
                  © 2026 Mamun Co-Foundr · Partnered with the University of Texas ·
                  <a href="{unsub}" style="color:{SHADE};text-decoration:underline;">Unsubscribe</a>
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
"""


def detail_row(label, value):
    return f"""<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="margin:0 0 8px;">
                  <tr>
                    <td class="stack" width="120" style="width:120px;vertical-align:top;font-family:{SANS};font-size:13px;line-height:1.6;color:{SHADE};">{label}</td>
                    <td class="stack" style="vertical-align:top;font-family:{SANS};font-size:13px;line-height:1.6;color:{CHARCOAL};">{value}</td>
                  </tr>
                </table>"""


TEMPLATES = {
    "welcome": dict(
        title="Welcome", eyebrow="WELCOME", kicker="Your first step",
        alt="Line drawing of the UT Tower",
        preheader="You're part of the first cohort of UT founders on the platform.",
        headline="Glad you're here, {{{firstName}}}.",
        body="".join([
            p("Welcome to UT co-foundr matching. I'm Tes, CEO and one of the co-founders here at Mamun Co-Foundr — we are really glad you're here."),
            p("You're joining through the University of Texas, which means you're part of the first cohort of UT founders running our co-founder discovery process. You signed up because you care about who you build with, not just what you build — and that's the whole reason the platform exists."),
            p(f'The most useful thing you can do right now is <a href="{SITE}" style="{LINK}">finish your profile</a> — it\'s how we understand who to match you with. Want me to walk you through it? Takes about five minutes.'),
            p(f'Just reply to this email, or <a href="https://calendly.com/mcfm-mamuncofoundr/30min" style="{LINK}">grab a time on my calendar</a> — whichever\'s easier.', last=True),
        ]),
        extra_rows=signoff("Tes", "Founder of Mamun Co-Foundr"),
    ),
    "weekly-summary": dict(
        title="Weekly Summary", eyebrow="WEEKLY SUMMARY", kicker="This week",
        alt="Line drawing of a chart trending upward",
        preheader="Here's who looked at your profile this week.",
        headline=f'<span style="color:{ORANGE};">{{{{{{viewCount}}}}}}</span> people viewed your profile.',
        body="".join([
            p("Hi {{{firstName}}} —"),
            p("Your profile had real traction this week. Someone took the time to read through what you're building — that's not noise, that's signal."),
            p("If your profile is incomplete or hasn't been updated recently, now is a good time. First impressions happen once.", last=True),
        ]),
        extra_rows=signoff() + button("LOG BACK IN &rarr;", SITE),
    ),
    "re-engagement": dict(
        title="We Missed You", eyebrow="WE MISSED YOU", kicker="Still building?",
        alt="Line drawing of an open door",
        preheader="Your profile is still live, and new UT founders join every week.",
        headline="It's been a while. Are you still looking?",
        body="".join([
            p("Hi {{{firstName}}} —"),
            p("We haven't seen you on UT co-foundr matching in about a month. We're not going to make a big deal of it — life moves fast, and building a company is hard enough without adding pressure from a platform."),
            p("Your profile is still live and your history is preserved. If you're still in the search, come back and we'll pick up where we left off. New UT founders join every week, and there may be matches waiting that weren't there before.", last=True),
        ]),
        extra_rows=signoff() + button("LOG BACK IN &rarr;", SITE),
    ),
    # Server-rendered with Handlebars (loop), so it keeps double braces. Not pushable as a Resend template as-is.
    "message-digest": dict(
        title="Message Digest", eyebrow="MESSAGE FEED", kicker="This week",
        alt="Line drawing of two speech bubbles",
        preheader="See who reached out to you.",
        headline=f'<span style="color:{ORANGE};">{{{{totalUnreadCount}}}}</span> new {{{{messageWord}}}}',
        body=p("Hi {{recipientName}} — here's what you missed.", last=True) + """
                {{#each messages}}
                <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-left:2px solid """ + ORANGE + """;margin:20px 0 0;">
                  <tr>
                    <td style="padding:4px 0 4px 16px;">
                      <p style="margin:0 0 6px;padding:0;font-family:""" + SANS + """;font-size:10px;font-weight:700;letter-spacing:2px;color:""" + CHARCOAL + """;text-transform:uppercase;">{{sender}}</p>
                      <p style="margin:0;padding:0;font-family:""" + SERIF + """;font-size:16px;line-height:1.6;color:""" + CHARCOAL + """;font-style:italic;">&ldquo;{{preview}}&rdquo;</p>
                    </td>
                  </tr>
                </table>
                {{/each}}""",
        extra_rows=button("LOG BACK IN &rarr;", SITE),
        support=True, unsub="{{unsubscribeUrl}}",
    ),
    "feature-announcement": dict(
        title="What's New", eyebrow="NEW", kicker="Product update",
        alt="Line drawing of a spark",
        preheader="Something new we've been working on.",
        headline="{{{featureName}}}",
        body="".join([
            p("Hi {{{firstName}}} — something new we've been working on."),
            p("{{{featureDescription}}}"),
            f'<p style="margin:8px 0 12px;padding:0;font-family:{SANS};font-size:11px;font-weight:700;letter-spacing:3px;color:{ORANGE};text-transform:uppercase;">What\'s changed</p>',
            accent_block("".join(
                f'<p style="margin:0 0 {m};padding:0;font-family:{SANS};font-size:15px;line-height:1.7;color:{CHARCOAL};">&rarr;&nbsp; {{{{{{benefit{i}}}}}}}</p>'
                for i, m in ((1, "8px"), (2, "8px"), (3, "0")))),
            p("{{{closingContext}}}", last=True),
        ]),
        extra_rows=signoff() + button("LOG BACK IN &rarr;", SITE),
    ),
    "mutual-match": dict(
        title="You matched!", eyebrow="NEW MATCH", kicker="Mutual match",
        alt="Line drawing of two joined loops",
        preheader="You both clicked We Match — {{{firstName}}}'s profile is inside.",
        headline="You matched with {{{firstName}}}.",
        body="".join([
            p("You both clicked We Match. Neither of you was notified until the other clicked too. {{{firstName}}}'s profile is below — when you're ready, send them a message."),
            f'<p style="margin:8px 0 2px;padding:0;font-family:{SERIF};font-size:20px;line-height:1.3;color:{CHARCOAL};">{{{{{{firstName}}}}}} {{{{{{lastName}}}}}}</p>',
            f'<p style="margin:0 0 16px;padding:0;font-family:{SANS};font-size:13px;line-height:1.6;color:{SHADE};">{{{{{{title}}}}}} · Austin, TX · Verified UT student · {{{{{{archetype}}}}}}</p>',
            accent_block(f'<p style="margin:0;padding:0;font-family:{SANS};font-size:14px;line-height:1.7;color:{CHARCOAL};">{{{{{{bio}}}}}}</p>'),
            detail_row("Interests", "{{{interests}}}"),
            detail_row("Looking for", "{{{lookingFor}}}"),
            detail_row("Venture stage", "{{{stage}}}"),
            detail_row("Degree", "{{{degree}}}"),
        ]),
        extra_rows=button("SEND {{{firstName}}} A MESSAGE &rarr;", SITE) + f"""
            <tr>
              <td style="padding:24px 0 0;">
                <p style="margin:0;padding:0;font-family:{SANS};font-size:12px;line-height:1.7;color:{SHADE};">This match happened inside the closed UT co-foundr matching cohort. Only verified utexas.edu students can match with each other on this platform.</p>
              </td>
            </tr>""",
    ),
    "cofounder-invite": dict(
        title="Co-founder request", eyebrow="INVITE", kicker="Co-founder request",
        alt="Line drawing of an envelope",
        preheader="{{{inviterName}}} wants to build with you — accept to link your profiles.",
        headline="{{{inviterName}}} wants to link up as co-founders.",
        body="".join([
            p("<strong>{{{inviterName}}}</strong> invited you to connect on UT co-foundr matching. If you accept, your two profiles link into one founding team — anyone viewing either card sees you're building together, and you get matched accordingly."),
            p("Nothing links until <strong>you</strong> say yes — and you can review or edit your role before confirming.", last=True),
        ]),
        extra_rows=button("REVIEW &amp; ACCEPT INVITE &rarr;", "{{{acceptUrl}}}") + f"""
            <tr>
              <td style="padding:16px 0 0;">
                <p style="margin:0 0 16px;padding:0;font-family:{SANS};font-size:12px;line-height:1.6;color:{SHADE};word-break:break-all;">Or paste this link into your browser:<br />{{{{{{acceptUrl}}}}}}</p>
                <p style="margin:0;padding:0;font-family:{SANS};font-size:13px;line-height:1.6;color:{SHADE};">Not expecting this? You can safely ignore this email — no link is created unless you accept.</p>
              </td>
            </tr>""",
    ),
    "cofounder-linked": dict(
        title="You're linked", eyebrow="LINKED", kicker="You're a team",
        alt="Line drawing of two linked chain rings",
        preheader="You and {{{linkedName}}} are now linked as co-founders.",
        headline="You're linked with {{{linkedName}}}.",
        body="".join([
            p("You and <strong>{{{linkedName}}}</strong> are now connected as co-founders on UT co-foundr matching. Both of your profiles show the <strong>Co-Founder</strong> block, and you're surfaced as one founding team in matching."),
            p("Looking to grow the team? You'll keep showing up in matching as a pair open to adding complementary members. Either of you can unlink anytime from your profile.", last=True),
        ]),
        extra_rows=button("GO TO YOUR DASHBOARD &rarr;", "{{{dashboardUrl}}}") + f"""
            <tr>
              <td style="padding:16px 0 0;">
                <p style="margin:0;padding:0;font-family:{SANS};font-size:12px;line-height:1.6;color:{SHADE};word-break:break-all;">Or paste this link into your browser:<br />{{{{{{dashboardUrl}}}}}}</p>
              </td>
            </tr>""",
    ),
}

if __name__ == "__main__":
    out = pathlib.Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    for key, cfg in TEMPLATES.items():
        (out / f"{key}.html").write_text(page(key=key, **cfg))
        print("built", key)
