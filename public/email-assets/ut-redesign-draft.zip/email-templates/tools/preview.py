"""Render staged templates with sample data (local images) to PNG previews."""
import re, sys, pathlib
from playwright.sync_api import sync_playwright
src, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
assets = pathlib.Path(__file__).resolve().parent.parent / "email-assets/illustrations"
S = dict(firstName="Maya", lastName="Okafor", viewCount="14", featureName="Founder availability windows",
  featureDescription="You can now set the hours you're open to co-founder conversations, so matches reach you when you actually have time to talk.",
  benefit1="Set weekly availability from your profile", benefit2="Matches see when you're free before they message",
  benefit3="Quiet hours pause notifications automatically", closingContext="It's live for every UT founder today — tell us what you think by replying to this email.",
  title="CS + Business Honors", archetype="Builder", bio="Shipping a dorm-to-dorm resale marketplace. Looking for someone who loves growth and operations as much as I love code.",
  interests="Marketplaces, climate, student life", lookingFor="Business / growth co-founder", stage="Prototype", degree="BS Computer Science, 2027",
  inviterName="Jordan Lee", acceptUrl="https://ut.mamuncofoundr.com/invite/abc123", linkedName="Jordan Lee",
  dashboardUrl="https://ut.mamuncofoundr.com/dashboard", RESEND_UNSUBSCRIBE_URL="#", unsubscribeUrl="#",
  recipientName="Maya", totalUnreadCount="2", messageWord="Messages")
MSGS = [("Jordan Lee", "Loved your marketplace idea — free for coffee Thursday?"), ("Priya Shah", "I've run growth for two campus startups. Happy to compare notes.")]
def fill(h):
    h = h.replace("https://ut.mamuncofoundr.com/email-assets/illustrations", "file://" + str(assets))
    m = re.search(r"\{\{#each messages\}\}(.*?)\{\{/each\}\}", h, re.S)
    if m: h = h.replace(m.group(0), "".join(m.group(1).replace("{{sender}}", s).replace("{{preview}}", t) for s, t in MSGS))
    return re.sub(r"\{\{\{?(\w+)\}?\}\}", lambda x: S.get(x.group(1), x.group(0)), h)
with sync_playwright() as p:
    b = p.chromium.launch()
    for f in sorted(src.glob("*.html")):
        tmp = out / f"_{f.name}"; tmp.write_text(fill(f.read_text()))
        for w in (600, 375):
            pg = b.new_page(viewport={"width": w, "height": 900}); pg.goto("file://" + str(tmp))
            pg.wait_for_load_state("networkidle")
            chk = pg.evaluate("""()=>({over: document.documentElement.scrollWidth>innerWidth,
              broken:[...document.images].filter(i=>!i.naturalWidth).length,
              leftover:(document.body.innerText.match(/\\{\\{[^}]*\\}\\}/g)||[])})""")
            print(f.stem, w, chk)
            pg.screenshot(path=str(out / f"{f.stem}-{w}.png"), full_page=True); pg.close()
    b.close()
