"""Original one-line ink illustrations for UT lifecycle emails.
Renders each as a 1080x600 PNG (displayed at 540x300) with the panel colour baked in."""
import sys, pathlib
from playwright.sync_api import sync_playwright

OUT = pathlib.Path(sys.argv[1])
INK = "#1f262c"
ORANGE, LIMESTONE, OFFWHITE = "#bf5700", "#d6d2c4", "#f7f6f4"
PEACH, PEACH_DEEP = "#f2ddcc", "#e5bc99"  # 20% / 40% burnt-orange tints

# name: (panel colour, accent dot colour, svg body in a 1080x600 space)
ART = {
 "welcome": (ORANGE, OFFWHITE, """
   <path d="M470 520 L470 250 L610 250 L610 520"/>
   <path d="M450 250 L630 250 L630 225 L450 225 Z"/>
   <path d="M490 225 L490 170 Q540 120 590 170 L590 225"/>
   <path d="M540 128 L540 92"/>
   <circle cx="540" cy="305" r="34"/><path d="M540 305 L540 284 M540 305 L556 316"/>
   <path d="M500 370 L500 420 M540 370 L540 420 M580 370 L580 420"/>
   <path d="M300 520 Q360 470 420 500 T470 520 L610 520 Q680 470 740 505 T800 520"/>
   <circle class="dot" cx="760" cy="170" r="30"/>"""),
 "weekly-summary": (LIMESTONE, ORANGE, """
   <path d="M300 470 L780 470"/>
   <path d="M330 470 Q390 430 430 440 T520 380 T610 330 T700 230"/>
   <path d="M660 236 L702 228 L708 272"/>
   <path d="M380 470 L380 430 M480 470 L480 405 M580 470 L580 360 M680 470 L680 300" class="thin"/>
   <circle class="dot" cx="702" cy="228" r="22"/>"""),
 "re-engagement": (PEACH, ORANGE, """
   <path d="M430 500 L430 150 L620 150 L620 500"/>
   <path d="M430 150 L540 190 L540 530 L430 500"/>
   <circle cx="518" cy="345" r="8"/>
   <path d="M300 520 L800 520"/>
   <path d="M620 470 Q690 430 700 360 Q712 290 770 300 Q820 310 800 360 Q790 390 760 380"/>
   <circle class="dot" cx="760" cy="180" r="26"/>"""),
 "message-digest": (OFFWHITE, ORANGE, """
   <path d="M330 200 Q330 150 380 150 L590 150 Q640 150 640 200 L640 310 Q640 360 590 360 L430 360 L370 410 L385 360 L380 360 Q330 360 330 310 Z"/>
   <path d="M690 260 Q740 260 740 300 L740 400 Q740 440 700 440 L695 440 L710 485 L655 440 L560 440 Q520 440 520 400 L520 370"/>
   <circle class="dot" cx="410" cy="255" r="16"/><circle cx="485" cy="255" r="16" class="fill"/><circle cx="560" cy="255" r="16" class="fill"/>"""),
 "feature-announcement": (ORANGE, OFFWHITE, """
   <path d="M540 150 L540 225 M540 375 L540 450 M390 300 L465 300 M615 300 L690 300"/>
   <path d="M435 195 L482 242 M598 358 L645 405 M645 195 L598 242 M482 358 L435 405"/>
   <path d="M300 500 Q420 470 540 500 T780 500" class="thin"/>
   <circle class="dot" cx="540" cy="300" r="36"/>"""),
 "mutual-match": (PEACH, ORANGE, """
   <path d="M540 300 Q470 180 390 210 Q310 240 330 320 Q350 400 440 380 Q500 365 540 300 Q580 235 640 220 Q730 200 750 280 Q770 360 690 390 Q610 420 540 300"/>
   <path d="M300 500 Q420 470 540 500 T780 500" class="thin"/>
   <circle class="dot" cx="540" cy="300" r="22"/>"""),
 "cofounder-invite": (LIMESTONE, ORANGE, """
   <path d="M330 230 L620 230 L620 440 L330 440 Z"/>
   <path d="M330 230 L475 350 L620 230"/>
   <path d="M330 440 L440 340 M620 440 L510 340" class="thin"/>
   <path d="M620 300 Q690 290 700 230 Q710 170 770 180 Q820 190 805 240"/>
   <circle class="dot" cx="790" cy="270" r="24"/>"""),
 "cofounder-linked": (PEACH_DEEP, ORANGE, """
   <rect x="330" y="240" width="250" height="120" rx="60" transform="rotate(-18 455 300)"/>
   <rect x="500" y="240" width="250" height="120" rx="60" transform="rotate(-18 625 300)"/>
   <path d="M300 500 L780 500" class="thin"/>
   <circle class="dot" cx="770" cy="170" r="24"/>"""),
}

def svg(bg, dot, body, seed):
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="600" viewBox="0 0 1080 600">
 <defs>
  <filter id="w"><feTurbulence type="fractalNoise" baseFrequency="0.011" numOctaves="2" seed="{seed}"/>
   <feDisplacementMap in="SourceGraphic" scale="9"/></filter>
  <clipPath id="r"><rect width="1080" height="600" rx="20"/></clipPath>
 </defs>
 <style>
  g.art * {{ fill:none; stroke:{INK}; stroke-width:7; stroke-linecap:round; stroke-linejoin:round; }}
  g.art .thin {{ stroke-width:4.5; }}
  g.art .dot {{ fill:{dot}; stroke:none; }}
  g.art .fill {{ fill:{INK}; stroke:none; }}
 </style>
 <rect width="1080" height="600" rx="20" fill="{bg}"/>
 <g class="art" clip-path="url(#r)" filter="url(#w)">{body}</g>
</svg>"""

OUT.mkdir(parents=True, exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1080, "height": 600})
    for i, (name, (bg, dot, body)) in enumerate(ART.items()):
        pg.set_content(f"<html><body style='margin:0;background:transparent'>{svg(bg, dot, body, i + 3)}</body></html>")
        pg.locator("svg").screenshot(path=str(OUT / f"{name}.png"), omit_background=True)
        print("wrote", name)
    b.close()
